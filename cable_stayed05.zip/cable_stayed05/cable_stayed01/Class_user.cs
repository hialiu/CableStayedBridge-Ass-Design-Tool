﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cable_stayed01
{
    class Class_user
    {
        public static String userID; //用户名
    }
}
